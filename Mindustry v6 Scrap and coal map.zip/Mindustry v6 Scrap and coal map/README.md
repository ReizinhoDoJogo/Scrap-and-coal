Scrap and coal, An multiplayer map for mindustry v6
Made by [green]Reizi[yellow]nhodo[blue]jogo
No  mods needed.